<?php
	class clk extends ana{}
?>