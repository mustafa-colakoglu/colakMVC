<?php
	class controller{
		public function __construct(){
			$this->load=new load();#load class ımızı çalıştırdık
		}
	}
?>