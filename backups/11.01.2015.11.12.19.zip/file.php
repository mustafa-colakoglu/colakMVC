<?php
	$data["file"]=__DIR__;
?>