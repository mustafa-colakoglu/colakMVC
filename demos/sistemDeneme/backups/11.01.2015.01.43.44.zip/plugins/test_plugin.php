<?php
	class deneme{
		const help="bilgiler";
		public function __construct(){
			echo "test";
		}
	}
?>