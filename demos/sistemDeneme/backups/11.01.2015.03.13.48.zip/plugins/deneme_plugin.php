<?php
	class deneme{
		public function __construct(){
			echo "deneme çalıştı mı?";
		}
		public function a(){
			echo "sdada";
		}
	}
?>