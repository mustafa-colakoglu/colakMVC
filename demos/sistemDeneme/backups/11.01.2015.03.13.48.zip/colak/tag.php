<?php
	class tag{
		public function tag($tag,$ic){
			echo "<".$tag.">".$ic."</".$tag.">";
		}
	}
?>