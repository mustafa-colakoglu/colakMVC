<?php
	$version="1.2";
	$currentVersion=@file_get_contents("http://localhost/currentVersion.txt");
?>